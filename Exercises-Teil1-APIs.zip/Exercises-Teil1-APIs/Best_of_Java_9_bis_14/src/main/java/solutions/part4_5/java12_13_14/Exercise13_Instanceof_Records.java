package solutions.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise13_Instanceof_Records 
{
	public double computeAreaV1(final Object figure) 
	{
		if (figure instanceof Square square) 
		{
			return square.sideLength * square.sideLength;
		} 
		else if (figure instanceof Circle circle) 
		{
			return circle.radius * circle.radius * Math.PI;
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}
	
	
	
	
	interface BaseFigure
	{
		double calcArea();
	}
	
	record Square(double sideLength) implements BaseFigure{

		@Override
		public double calcArea() {
			return sideLength * sideLength;
		}
	}

	record Circle(double radius) implements BaseFigure 
	{
		@Override
		public double calcArea() 
		{
			return radius * radius * Math.PI;
		}
	}

	public double computeArea(final BaseFigure figure) 
	{
		return figure.calcArea();
	}
}
