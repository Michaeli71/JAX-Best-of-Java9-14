package solutions.part3;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise02_Arrays 
{
	public static void main(final String[] args) 
	{
		//                      01234012345678901234
		final byte[] string1 = "ABC-DEF-GHIJKLMNOPQT".getBytes();
		final byte[] string2 = "ABC-dEF-GHIJKLMNOPqT".getBytes();
		System.out.println(Arrays.mismatch(string1, string2));
		System.out.println(Arrays.mismatch(string1, 5, 20, 
		                                   string2, 5, 20));
		
		final byte[] first =  { 1,1,0,1,1,0,1,1,1,1,0,1,0};
		final byte[] second = { 1,1,0,1,1,0,1,1,1,1,1,1,1};
		
		// An welcher Position unterscheiden sich die beiden Arrays		
		final int firstMismatch = Arrays.mismatch(first, second);
		System.out.println("First difference: " + firstMismatch);
		System.out.println("Next difference: " + Arrays.mismatch(first, firstMismatch+1, first.length, 
				                                                 second, firstMismatch+1, second.length));
	}
}
