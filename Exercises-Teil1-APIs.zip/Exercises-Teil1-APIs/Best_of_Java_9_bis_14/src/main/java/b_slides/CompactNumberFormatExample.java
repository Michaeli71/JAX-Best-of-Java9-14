package b_slides;

import java.text.NumberFormat;
import java.text.NumberFormat.Style;
import java.text.ParseException;
import java.util.Locale;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class CompactNumberFormatExample 
{
	public static void main(String[] args) throws ParseException
	{
	    System.out.println("US/SHORT parsing:");
	
	    var shortFormat = NumberFormat.getCompactNumberInstance(Locale.US, Style.SHORT);
	    System.out.println(shortFormat.parse("1 K")); // ACHTUNG
	    System.out.println(shortFormat.parse("1K"));
	    System.out.println(shortFormat.parse("1M"));
	    System.out.println(shortFormat.parse("1B"));

	    System.out.println("\nUS/LONG parsing:");
	
	    var longFormat = NumberFormat.getCompactNumberInstance(Locale.US, Style.LONG);
	    System.out.println(longFormat.parse("1 thousand"));
	    System.out.println(longFormat.parse("1 million"));
	    System.out.println(longFormat.parse("1 billion"));
	}	
}

