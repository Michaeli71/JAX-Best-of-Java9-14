package exercises.part3;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise06_InpuStream 
{
	public static void main(final String[] arguments) throws IOException
	{
		final String fileName = arguments[0];

		copyFileJdk9(fileName);
	}

	private static void copyFileJdk9(final String fileName) throws IOException, FileNotFoundException 
	{
		// TODO
	}
	
	private static void copyFileUsingStream(File source, File dest) throws IOException 
	{
	    try (final InputStream is = new FileInputStream(source);
	    	 final OutputStream os = new FileOutputStream(dest))
	    {
	    	final byte[] buffer = new byte[2048];
			int length;
			while ((length = is.read(buffer)) > 0) 
			{
			    os.write(buffer, 0, length);
			}
			os.flush();
	    } 
	}
}
