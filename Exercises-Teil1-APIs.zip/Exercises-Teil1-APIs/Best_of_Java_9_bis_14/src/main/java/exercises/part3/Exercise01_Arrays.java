package exercises.part3;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise01_Arrays 
{
	public static void main(final String[] args) 
	{
		final byte[] string1 = "ABC-DEF-GHI".getBytes();
		final byte[]  string2 = "DEF".getBytes();
		System.out.println(Arrays.equals(string1, string2));
		System.out.println(Arrays.equals(string1, 4, 7, 
		                                 string2, 0, 3));
		
		final String text = "BLABLASECRET-INFO:42BLABLA";
		final String search = "SECRET-INFO:42";
		
		// Java 8 and before
		// TODO
		
		// finde eine Überschneidung mit dem gesamten Text
		// TODO				
	}
}
