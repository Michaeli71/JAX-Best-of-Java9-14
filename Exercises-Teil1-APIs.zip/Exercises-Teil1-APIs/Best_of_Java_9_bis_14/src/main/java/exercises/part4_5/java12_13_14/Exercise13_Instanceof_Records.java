package exercises.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise13_Instanceof_Records 
{
	record Square(double sideLength) {
	}
	
	record Circle(double radius) {
	}
	
	public double computeAreaOld(final Object figure) 
	{
		if (figure instanceof Square) 
		{
			final Square square = (Square) figure;
			return square.sideLength * square.sideLength;
		} 
		else if (figure instanceof Circle) 
		{
			final Circle circle = (Circle) figure;
			return circle.radius * circle.radius * Math.PI;
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}

}
