module timeserver {
	
	provides com.timeexample.spi.TimeService
	with com.timeexample.services.TimeUtils;
	
	requires timeservice;
	requires java.logging;
	
}