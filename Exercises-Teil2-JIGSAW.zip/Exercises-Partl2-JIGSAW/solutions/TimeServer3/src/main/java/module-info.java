module timeserver {
	exports com.timeexample.services;
	requires java.logging;
	//requires java.logging;
	
}